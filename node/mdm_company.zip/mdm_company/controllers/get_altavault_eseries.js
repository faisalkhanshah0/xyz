//const company_id = require('../db_apis/get_cmat_info.js');
const oracledb = require('oracledb');
const dbConfig = require('../config/database.js');

// Definition of get_altavault routes function starts here
async function get_altavault(req, res, next) {
  try {
	  
	   console.log('inside controller');
		const connection1 = await oracledb.getConnection(dbConfig.teimdb); // Db connection created
		let serial_number = req.query.serial_number.trim(); // Splitting query string variable 
		let obj;
		let options = {
			outFormat: oracledb.ARRAY   // query result format
			// extendedMetaData: true,   // get extra metadata
			// fetchArraySize: 100       // internal buffer allocation size for tuning
		};

		 let binds = {serial_number};  // var to bind with first query
		 let result = await connection1.execute("select SYSTEM_SERIAL_NUMBER,part_number,WARRANTY_END_DATE,asup_status,nvl(PARTNER_SERIAL_NUMBER ,'-99') as sln,HARDWARE_SERV_END_DATE,PRODUCT_SERIES,nvl(LAST_ASUP_DATE,sysdate) as lad, 'Valid' as status,'User Has Access to Serial Number' as error from EIM_PR_SYSTEM where SYSTEM_SERIAL_NUMBER=:serial_number", binds, options);
		
		console.log(result.rows);
		if(result.rows.length){
			obj = {
				EntryPoint:result.rows[0][6],
				Primary_Serial_Number: result.rows[0][0],
				Partner_Serial_Number: result.rows[0][4],
				Primary_Serial_Number_Status: result.rows[0][8],
				Primary_Serial_Number_Error: result.rows[0][9],
				ASUP_STATUS: result.rows[0][3],
				Last_Asup_Date: result.rows[0][7]
			}

			let obj3 = {
				"Existing_Response_Time": "NBD PREMIUM ONSITE",
				"Existing_Service_End_Date": result.rows[0][5],
				"Existing_Warranty_End_Date": result.rows[0][2]
		 }
			
			obj.Existing_Service = obj3;
		
			 let binds = {Part_number : result.rows[0][1]};  // var to bind with second query
			 let result2 = await connection1.execute("select PART_NUMBER, DRIVE_CAPACITY||'-'||NUMBER_OF_DRIVES||'-'||STORAGE_CAPACITY_NUMBER||'-'||SHELF_TYPE||'-'||CONTROLLER_COUNT as AHP,ph6,ph5 from EIM_DRM_PRODUCT_DETAILS where PART_NUMBER=:Part_number", binds, options);
			console.log(result2);
			let obj2 = {
				"AVA_Hardware_Parts": result2.rows[0][1],
				"AVA_Storage_Parts": result2.rows[0][2],
				"AVA_SW_Cap_Parts": result2.rows[0][3]
			}
			obj.AV_System = obj2;
	

		
		}

   
    if(obj){
      console.timeEnd("Time this");
      res.status(200).json(obj);
    }
    else{
      res.status(200).json({status: 404,message:'Data Not Found'});
    }

	
  } catch (err) {
    next(err);
  }
}
// Definition of get_altavault routes function ends here


// Definition of get_eseries routes function starts here
async function get_eseries(req, res, next) {
  try {

		// const connection1 = await oracledb.getConnection(dbConfig.fcmatdb); // Db connection created
		// let serial_number = req.query.serial_number.trim(); // Splitting query string variable 
		// let obj;
		// let options = {
		// 	outFormat: oracledb.ARRAY   // query result format
		// 	// extendedMetaData: true,   // get extra metadata
		// 	// fetchArraySize: 100       // internal buffer allocation size for tuning
		// };

		// let binds = {serial_number};  // var to bind with first query
		// let result = await connection1.execute("select * from Tablename where serialno = :serial_number",
		// 			binds, options);

		obj = {
			Entry_Point: "Eseries",
			Primary_Serial_Number: "1124FG000524",
			Partner_Serial_Number: "211409000190",
			Primary_Serial_Number_Status: "Valid",
			Primary_Serial_Number_Error: "User Has Access to Serial Number",
			ASUP_STATUS: "ON",
			Last_Asup_Date: "5/5/2017",
			ESeries_Software:[]
		}
	
		//Query 2
	
		let obj2 = {
			Family: "E-SERIES",
			System: "2610",
			"Internal Storage": "E2600 2GB CNTL NO HIC",
			Type: "High Availability (Duplex)"
	
		}
	
		obj.ESeries_System = obj2;
	
	
			//Query 4
			let result4 = ["FDE_SKM-2600","REMOTE_MIRRORING"];
			for(let i=0;i<result4.length;i++){
				obj.ESeries_Software.push(result4[i]);
			}
							
	
		//Query 5
		let result5 = [3,4];
	
		for(let i=0;i<result5.length;i++){
	
			let obj5 = {
									Storage: [],
									Expansion_Enclosure: [],
									Base_Enclosure: "DE5600 DISKLESS CM",
								 }
	
				//Query 6
								 
				let result6 = [5,6];
				for(let j=0;j<result6.length;j++){
					let obj6 = {
						"Storage Type": "DE6600 NLSAS 3TB",
						"Storage-Quantity": "10"
	
						}
	
					obj5.Storage.push(obj6);   
				}  
				
				 //Query 3
		let result3 = [1,2];
	
		for(let i=0;i<result3.length;i++){
			let obj3 = { 
									"name": "DE6600 DISKLESS DM" ,
									"qty": "10"
								}
	
								obj5.Expansion_Enclosure.push(obj3);  
				}
				obj.ESeries_Storage = obj5;        
	
	
		}
	
	
		//Query 7
	
		let obj7 = {
				Existing_Response_Time: "NBD PREMIUM ONSITE",
				Existing_Service_End_Date: "12/12/2018",
				Existing_Warranty_End_Date: "12/12/2018"
	 }
		
		obj.Existing_Service = obj7;
	
		if(obj){
			console.timeEnd("Time this");
			res.status(200).json(obj);
		}
		else{
			res.status(200).json({status: 404,message:'Data Not Found'});
		}
	
  } catch (err) {
    next(err);
  }
}
// Definition of get_eseries routes function ends here
module.exports = {
	get_altavault,
	get_eseries
}